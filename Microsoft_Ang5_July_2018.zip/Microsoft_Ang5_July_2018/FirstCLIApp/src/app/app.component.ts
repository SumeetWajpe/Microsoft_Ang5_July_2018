import { Component } from '@angular/core';
import {HttpClient} from '@angular/common/http';

import {map,filter} from 'rxjs/operators';
// import {toPromise} from 'rxjs/operator/toPromise';


@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'app';

  courses:string[] = ['React','Node','Angular']

  
}
