import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import {FormsModule} from '@angular/forms';
import {HttpModule} from '@angular/http';
import {RouterModule, Routes} from '@angular/router';


import { AppComponent }  from './app.component';
import { CourseComponent } from './course.component';
import { ShoppingCartComponent } from './shoppingcart.component';
import { ProductComponent } from './product.component';
import { QuantityPipe } from './quantity.pipe';
import { NewCourseComponent } from './newcourse.component';
import { CourseService } from './course.service';
import { PostsComponent } from './posts.component';
import { PostDetailComponent } from './post.detail.component';

// import {routes} from './routes' 

const routes:Routes=[
  {path:'posts',component:PostsComponent},
  {path:'post/:id',component:PostDetailComponent},
  {path:'cart',component:ShoppingCartComponent},
  {path:'',component:NewCourseComponent},
  {path:'**',redirectTo:'/posts' }
];

@NgModule({
  imports:      [ BrowserModule,FormsModule,HttpModule,
    RouterModule.forRoot(routes) ],
  declarations: [ AppComponent,
    CourseComponent,
    ShoppingCartComponent,
    ProductComponent,
    QuantityPipe,NewCourseComponent,
    PostsComponent,PostDetailComponent
   ],
  bootstrap:    [ AppComponent ],
  providers:[CourseService]
})
export class AppModule { }
