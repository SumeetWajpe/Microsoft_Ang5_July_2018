export class CourseService{
    listOfCourses:string[]=['React','Node','Redux'];

    getAllCourses():string[]{
        return this.listOfCourses;
    }
    addNewCourse(newCourse:string):void{
        this.listOfCourses.push(newCourse);
    }
}