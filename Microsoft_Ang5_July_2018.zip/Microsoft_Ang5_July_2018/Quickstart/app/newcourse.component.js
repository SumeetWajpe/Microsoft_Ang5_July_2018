"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var course_service_1 = require("./course.service");
var NewCourseComponent = (function () {
    function NewCourseComponent(servObj) {
        this.servObj = servObj;
        this.courses = [];
        this.newCourse = "";
    }
    NewCourseComponent.prototype.GetAllCourses = function () {
        this.courses = this.servObj.getAllCourses();
    };
    NewCourseComponent.prototype.AddNewCourse = function () {
        this.servObj.addNewCourse(this.newCourse);
    };
    return NewCourseComponent;
}());
NewCourseComponent = __decorate([
    core_1.Component({
        selector: "new-course",
        template: "\n    <h1> New Course </h1>\n\n    <b> List Of Courses </b>\n    <ul>    <li *ngFor=\"let c of courses\">{{c}}</li>    </ul>\n    <input type=\"button\"     value=\"Get Courses !\"\n    (click)=\"GetAllCourses()\"    class=\"btn btn-primary\"     />\n\n     Enter A New Course : <input type=\"text\" \n     [(ngModel)]=\"newCourse\" />\n     <input type=\"button\"      value=\"Add\"     class=\"btn btn-success\"\n     (click)=\"AddNewCourse()\" />\n    ", providers: [course_service_1.CourseService]
    }),
    __metadata("design:paramtypes", [course_service_1.CourseService])
], NewCourseComponent);
exports.NewCourseComponent = NewCourseComponent;
//# sourceMappingURL=newcourse.component.js.map