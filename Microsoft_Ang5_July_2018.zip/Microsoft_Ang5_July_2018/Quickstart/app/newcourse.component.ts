import { Component, Input } from "@angular/core";
import { CourseService } from "./course.service";

@Component({
    selector:`new-course`,
    template:`
    <h1> New Course </h1>

    <b> List Of Courses </b>
    <ul>    <li *ngFor="let c of courses">{{c}}</li>    </ul>
    <input type="button"     value="Get Courses !"
    (click)="GetAllCourses()"    class="btn btn-primary"     />

     Enter A New Course : <input type="text" 
     [(ngModel)]="newCourse" />
     <input type="button"      value="Add"     class="btn btn-success"
     (click)="AddNewCourse()" />
    `,    providers:[CourseService] })
export class NewCourseComponent{
    courses:string[]=[];
    newCourse:string="";
       constructor(public servObj:CourseService){ // DI         
       }
       GetAllCourses(){
        this.courses = this.servObj.getAllCourses();
       }
       AddNewCourse(){
           this.servObj.addNewCourse(this.newCourse);
       }
}