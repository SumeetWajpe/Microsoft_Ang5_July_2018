import { Component, OnInit } from "@angular/core";
import { ActivatedRoute } from "@angular/router";
import { Posts } from "./posts.model";

@Component({
    selector:`post-detail`,
    template:`<h2>Post Details for {{postId}} </h2>   
    
    <b> Body : </b> {{currPost.body}}    
    `
})
export class PostDetailComponent implements OnInit{       
    postId:number;
    currPost:Posts;
    constructor(private currRoute:ActivatedRoute){      }     
        ngOnInit(){
                 this.currRoute.params.subscribe(
                    p => {
                        this.postId = p["id"];
                        let allPosts = JSON.parse(localStorage["posts"]);
                        this.currPost = allPosts.find(
                            (cPost:Posts) => cPost.id == this.postId 
                        )                        
                    }              
                )
        }
}