import { Component, Input, OnInit, OnDestroy } from "@angular/core";
import { PostsService } from "./posts.service";

@Component({
    selector:`posts`,
    template:` 

    <h1>Posts </h1>

    <ul>
        <li *ngFor="let p of allPosts">
      <a routerLink="/post/{{p.id}}">  {{p.title}}  </a>
        </li>
    </ul>
     
    `,providers:[PostsService]
})
export class PostsComponent {//implements OnInit,OnDestroy{
    allPosts:any = [];
    //Using Observable Collection !
     constructor(private postsServObj:PostsService){
       var obserResponse = this.postsServObj.getPosts();

       obserResponse.subscribe((response)=>{
        this.allPosts = response;
        localStorage["posts"]= JSON.stringify(response);// store the JSON
    },
    (err)=>{
        console.log(err);
});
     }

// constructor(private postsServObj:PostsService){
   
//   }

//   ngOnInit(){
//     let aPromise = this.postsServObj.getPosts();
//     aPromise.then(
//             (response)=>{
//                 this.allPosts = response.json();// fetches the body of response & converts to js Object
//             },
//             (err)=>{
//                 console.log('Rejected !' + err);// server side error logging !  
//             }
//     )
//   }

  ngOnDestroy(){
      // final resource deallocation code !
      // unsubcribing
      //events unsubscribtion
  }
}