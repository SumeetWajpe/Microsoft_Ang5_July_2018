"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Posts = (function () {
    function Posts(id, userId, body, title) {
        this.id = id;
        this.userId = userId;
        this.body = body;
        this.title = title;
    }
    return Posts;
}());
exports.Posts = Posts;
//# sourceMappingURL=posts.model.js.map