export class Posts{
    constructor(public id?:number,public userId?:number,public body?:string,public title?:string){
        
    }
}