import {Http} from '@angular/http';
import { Injectable } from '@angular/core';
import 'rxjs/add/operator/toPromise';
import 'rxjs/add/operator/map';
import { Observable } from 'rxjs/Observable';
import {Posts} from './posts.model';

@Injectable()
export class PostsService{
    constructor(private httpObj:Http){
    }
    getPosts():Observable<Posts>{
        // make ajax request !
      return  this.httpObj.get('https://jsonplaceholder.typicode.com/posts').map( res => res.json() )
   }

//    getPosts(){
//         // make ajax request !
//       return  this.httpObj.get('https://jsonplaceholder.typicode.com/posts').toPromise();     
      
//     }
}