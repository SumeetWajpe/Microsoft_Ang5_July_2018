import { Component, Input } from "@angular/core";

import {Product} from './product.model';

@Component({
    selector:`product`,
    templateUrl:'./app/product.template.html',   
    styleUrls:[`./app/product.style.css`]
})
export class ProductComponent{
       @Input()     prodDetails:Product=new Product();
       isFree:boolean=false;
       isHighlighted:boolean=true;
       isBordered:boolean=true;
       classToBeApplied:string="productStyle";
       testProp:Product = undefined;
}