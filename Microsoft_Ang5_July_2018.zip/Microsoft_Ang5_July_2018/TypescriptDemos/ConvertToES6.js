let z = 1000;
var Square = x => x * x;
