var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var x = 100; // Type Inference
// x = "Hello !";
var str; // Type annotation !
var boolVar;
var y;
var anyTypeVar;
anyTypeVar = "Typescript !";
anyTypeVar = 2000;
//Object
var person = { name: 'Sumeet', location: 'Pune' };
// Arrays
var cars = ['BMW', 'AUDI', 'FERRARI'];
// for
// for-in
// for(let c in cars){
//     console.log(cars[c])
// }
// for-of (typescript)
// for(let c of cars){
//     console.log(c);
// }
// cars.forEach(function(car,index){
//     // console.log(' Car : ' + car + " is at an index : " + index )
//     console.log(`Car: ${car} is at an index ${index} `)
// })
// Using Generics
var moreCars = new Array('TATA', 'MARUTI', 'MAHINDRA');
var s;
function Addition(x, y) {
    if (x < 0) {
        return "x should be greater than 0 !";
    }
    return x + y;
}
var result = Addition(20, 30);
// function Test():void{
//         return 100
// }
if (true) {
    var blockedScopedVar = 1000;
    if (true) {
        console.log(blockedScopedVar);
    }
}
//console.log(blockedScopedVar); // Error !
var PI = 3.14;
// PI = 3.14565; // Error !
var multiLineString = "kjfjhjfhgjfhg\nknknfnjg\nlsjfgfjgbfj\nsdjbfjdbf\nknfnfnknfk";
//Optional Parameters
// function PrintBooks(author?:string,title?:string,noOfPages?:number){
//     author = author || "Unknown"; // older way - short circuiting
//     console.log(author,title,noOfPages);
// }
// Default Parameters
function PrintBooks(author, title, noOfPages) {
    if (author === void 0) { author = "Unknown"; }
    if (title === void 0) { title = "Unknown"; }
    if (noOfPages === void 0) { noOfPages = 0; }
    console.log(author, title, noOfPages);
}
PrintBooks();
PrintBooks("Dr. APJ Abdul Kalam", "Wings Of Fire", 300);
// function Square(x){
//     return x * x;
// }
//Function as an expresion !
var Square = function (x) {
    return x * x;
};
// Arrow Functions
// var Square = (x) => {
//     return x*x;
// }
// OR
var Square = function (x) { return x * x; };
cars.forEach(function (car, index) {
    // console.log(' Car : ' + car + " is at an index : " + index )
    console.log("Car: " + car + " is at an index " + index + " ");
});
// OR
cars.forEach(function (car, index) { return console.log("Car: " + car + " is at an index " + index + " "); });
function Emp() {
    var _this = this;
    this.salary = 200000;
    setTimeout(function () {
        console.log(_this.salary);
    }, 2000);
}
var company = {
    name: 'Microsoft',
    location: 'Hyderabad',
    noOfEmployees: 20000
};
var Car = /** @class */ (function () {
    function Car(name, speed) {
        if (name === void 0) { name = "i20"; }
        if (speed === void 0) { speed = 200; }
        this.name = name;
        this.speed = speed;
    }
    Car.prototype.Accelerate = function () {
        return ("The car " + this.name + " is running at " + this.speed + " kmph !");
    };
    return Car;
}());
//var c = new Car();
// c.name = "i20";
// c.speed = 200;
//c.Accelerate();
var JamesBondCar = /** @class */ (function (_super) {
    __extends(JamesBondCar, _super);
    function JamesBondCar(n, s, fly, invisible) {
        var _this = _super.call(this, n, s) || this;
        _this.canFly = fly;
        _this.beInvisible = invisible;
        return _this;
    }
    JamesBondCar.prototype.Accelerate = function () {
        return _super.prototype.Accelerate.call(this) + " Can It Fly ?" + this.canFly;
    };
    return JamesBondCar;
}(Car));
var jbc = new JamesBondCar("Aston Martin", 500, true, true);
console.log(jbc.Accelerate());
var Employee = /** @class */ (function () {
    function Employee() {
    }
    Employee.prototype.talk = function () {
    };
    return Employee;
}());
