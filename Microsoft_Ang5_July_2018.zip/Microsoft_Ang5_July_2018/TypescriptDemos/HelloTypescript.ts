var x = 100; // Type Inference
// x = "Hello !";

var str:string;// Type annotation !
var boolVar:boolean;
var y:number;
var anyTypeVar;
anyTypeVar = "Typescript !";
anyTypeVar = 2000;

//Object
var person:any ={name:'Sumeet',location:'Pune'};
// Arrays
var cars:string[] = ['BMW','AUDI','FERRARI'];

// for
// for-in
// for(let c in cars){
//     console.log(cars[c])
// }
// for-of (typescript)
// for(let c of cars){
//     console.log(c);
// }
// cars.forEach(function(car,index){
//     // console.log(' Car : ' + car + " is at an index : " + index )
//     console.log(`Car: ${car} is at an index ${index} `)
// })

// Using Generics
var moreCars:Array<string> = new Array<string>('TATA','MARUTI','MAHINDRA');

var s:string|number;

function Addition(x:number,y:number):number|string{

        if(x<0){
            return "x should be greater than 0 !"
        }

    return x + y;
}

var result:number|string = Addition(20,30);

// function Test():void{
//         return 100
// }

if(true){
    let blockedScopedVar:number =1000;

        if(true){
            console.log(blockedScopedVar)
        }
}
//console.log(blockedScopedVar); // Error !

const PI = 3.14;
// PI = 3.14565; // Error !

var multiLineString = `kjfjhjfhgjfhg
knknfnjg
lsjfgfjgbfj
sdjbfjdbf
knfnfnknfk`;


//Optional Parameters
// function PrintBooks(author?:string,title?:string,noOfPages?:number){
//     author = author || "Unknown"; // older way - short circuiting
//     console.log(author,title,noOfPages);
// }

// Default Parameters
function PrintBooks(author:string="Unknown",title:string="Unknown",noOfPages:number=0){
    console.log(author,title,noOfPages);
}

PrintBooks();
PrintBooks("Dr. APJ Abdul Kalam","Wings Of Fire",300);




// function Square(x){
//     return x * x;
// }

//Function as an expresion !
var Square = function(x){
        return x *x;
}

// Arrow Functions
// var Square = (x) => {
//     return x*x;
// }

// OR

var Square = x => x*x;

cars.forEach(function(car,index){
    // console.log(' Car : ' + car + " is at an index : " + index )
    console.log(`Car: ${car} is at an index ${index} `)
});

// OR

cars.forEach((car,index) => console.log(`Car: ${car} is at an index ${index} `))

function Emp(){
    this.salary = 200000;    
    setTimeout(()=>{
            console.log(this.salary)
    },2000)
}


// Interfaces
interface ICompany{
    name:string;
    location:string;
    noOfEmployees:number;
    isMNC?:boolean;
    getDetails?():any;
}

var company:ICompany = {
    name:'Microsoft',
    location:'Hyderabad',
    noOfEmployees:20000};
    

    class Car{
        private id:number;
        name:string;
        speed:number;   

        constructor(name:string="i20",speed:number=200){
                this.name = name;
                this.speed = speed;
        }
        
        Accelerate(){
            return (`The car ${this.name} is running at ${this.speed} kmph !`)
        }
    }
    //var c = new Car();
    // c.name = "i20";
    // c.speed = 200;
    //c.Accelerate();

    class JamesBondCar extends Car{
        canFly:boolean;
        beInvisible:boolean;
        constructor(n:string,s:number,fly:boolean,invisible:boolean){
            super(n,s);
            this.canFly = fly;
            this.beInvisible = invisible;
        }
        Accelerate(){
            return super.Accelerate() + " Can It Fly ?" + this.canFly
        }
    }
    var jbc = new JamesBondCar("Aston Martin",500,true,true);
    console.log(jbc.Accelerate());

    interface IPerson{
        name:string;
        age:number;
        walk?():void;
        talk():void;
    }
    interface IEmployee {
        id:number;
        email:string;
    }
    
    class Employee implements IEmployee,IPerson{
        name:string;
        age:number;
        id:number;
        email:string;
        talk(){
        }
    }