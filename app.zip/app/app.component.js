"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
var core_1 = require("@angular/core");
var course_model_1 = require("./course.model");
var AppComponent = (function () {
    function AppComponent() {
        this.imageUrl = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTHwFzbJ3-YBhNYgJbATec-yX33eoscb96mK-sLrCsFOnTh6vTf";
        this.courses = [
            new course_model_1.Course("React", "3 Days"),
            new course_model_1.Course("Node", "3 Days"),
            new course_model_1.Course("Redux", "2 Days"),
            new course_model_1.Course("Backbone", "3 Days")
        ];
    }
    return AppComponent;
}());
AppComponent = __decorate([
    core_1.Component({
        selector: 'my-app',
        template: "<cart></cart>"
        // template:`  
        //     <ul>
        //     <li *ngFor="let c of courses">
        //       {{c}}
        //     </li>
        //     </ul> 
        // `
        // template: `
        // <img src="{{imageUrl}}" height="200px" width="200px" />
        // <img [src]="imageUrl" height="200px" width="200px" />
        // <div *ngFor="let c of courses">
        //     <course [coursedetails]="c"></course>
        // </div>  
        // `,
    })
], AppComponent);
exports.AppComponent = AppComponent;
//# sourceMappingURL=app.component.js.map