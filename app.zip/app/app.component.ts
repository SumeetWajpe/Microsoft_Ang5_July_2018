import { Component } from '@angular/core';

import {CourseComponent}  from './course.component';
import {Course} from './course.model';


@Component({
  selector: 'my-app',
  template:`<cart></cart>`
  // template:`  
  //     <ul>
  //     <li *ngFor="let c of courses">
  //       {{c}}
  //     </li>
  //     </ul> 
  // `
  // template: `

  // <img src="{{imageUrl}}" height="200px" width="200px" />
  // <img [src]="imageUrl" height="200px" width="200px" />


  // <div *ngFor="let c of courses">
  //     <course [coursedetails]="c"></course>
  // </div>  
  // `,
})
export class AppComponent  { 

  imageUrl:string = "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTHwFzbJ3-YBhNYgJbATec-yX33eoscb96mK-sLrCsFOnTh6vTf"

  courses:Course[] = [
   new Course("React","3 Days"),
   new Course("Node","3 Days"),
   new Course("Redux","2 Days"),
   new Course("Backbone","3 Days")
  ];
}
